#include <stdio.h>
#include <string.h>
#include "iniutilit.h"
#define MAXBUFLEN 256

int iniGetString(const char *pszSection, const char *pszEntry, const char *pszDefault,
   char *pszRetBuf, unsigned int uiBufLen, const char *pszFileName)
{
   FILE *fpIni;
   char szBuf[MAXBUFLEN+1], *psz1, *psz2, *psz;
   int iSectFlag, iLen;

   strcpy(pszRetBuf, pszDefault);
   if((fpIni= fopen(pszFileName,"r")) == NULL)
   {
	  return (-1);
      //AnsiToUnicode(pszFileName,fileName,sizeof fileName);
      //if((fpIni= _wfopen(fileName,L"r")) == NULL)   return (-2);
   }
   /*** check section ***/
   iSectFlag= 0;
   while(!feof(fpIni))
   {
      if (fgets(szBuf,MAXBUFLEN,fpIni) == NULL)   break;
      psz= szBuf;

      while(*psz!='[' && *psz!='#' && *psz!='\0')   psz++;
      if (*psz!='[')   continue;

      psz++;
      while(*psz==' ' || *psz=='\t')   psz++;
      psz1= psz;
      while(*psz!=']' && *psz!='\0')   psz++;
      if (*psz=='\0')  continue;
      while(*(psz-1)==' ' || *(psz-1)=='\t')   psz--;
      *psz= '\0';

      if (!strcmp(psz1, pszSection))
      {
         iSectFlag= 1;
         break;
      }
   }/*** while ***/
   if (!iSectFlag)
   {
      fclose(fpIni);
      return (-1);
   }

   /*** check entry ***/
   while(!feof(fpIni))
   {
      if(fgets(szBuf,MAXBUFLEN,fpIni) == NULL)   break;
      psz= szBuf;
      while(*psz==' ' || *psz=='\t')   psz++;
      if (*psz=='#' || *psz=='\0')   continue;
      if (*psz=='[')   break;

      psz1= psz;
      while(*psz!='=' && *psz!='\0')   psz++;
      if (*psz=='\0')   continue;
      psz2= psz+1;
      if (psz1==psz)   continue;
      while(*(psz-1)==' ' || *(psz-1)=='\t')   psz--;
      *psz= '\0';

      if (strcmp(psz1,pszEntry))   continue;
      fclose(fpIni);

      psz= psz2;
      while(*psz==' ' || *psz=='\t')  psz++;
      psz2= psz;
      while(*psz!='\0' && !(*psz=='/' && *(psz+1)=='*'))   psz++;
      while(*(psz-1)==' ' || *(psz-1)=='\t' || *(psz-1)==0x0a ||
         *(psz-1)==0x0d)   psz--;
      *psz= '\0';

      iLen= (int)strlen(psz2);
      if (iLen==0)
      {
         return (-1);
      }

      if ((unsigned)iLen>uiBufLen)   iLen= uiBufLen;
      memcpy(pszRetBuf, psz2, iLen);
      *(pszRetBuf+iLen)= '\0';
      return (0);
   }

   fclose(fpIni);
   return (-1);
}

int iniGetInt(const char *pszSection, const char *pszEntry, int lDefault,
   int *plVal, const char *pszFileName)
{
   char szRet[13], szDef[13], *psz;
   int iRet;

   sprintf(szDef, "%d", lDefault);
   iRet= iniGetString(pszSection, pszEntry, szDef, szRet, 12, pszFileName);

   psz= szRet;
   if (*psz=='0' && (*(psz+1)=='x' || *(psz+1)=='X'))
      sscanf(psz+2, "%x", plVal);
   else
      sscanf(szRet, "%d", plVal);
   return(iRet);
}
