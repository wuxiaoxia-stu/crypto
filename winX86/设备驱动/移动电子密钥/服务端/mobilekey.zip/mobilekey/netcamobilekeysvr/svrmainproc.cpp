/**
 * NETCA��Ȩ����2017
 * �ļ����ƣ�svrmainproc.cpp
 * �ļ�˵������ת������������ʵ��
 * �汾��V1.0
 * ���ߣ���ľ��
 * ������ڣ�2017-07-24

 * ======= �޸ļ�¼ =========
 * �޸�˵����
 * �޸�ʱ�䣺
 * �޸��ˣ�
 */

#include "../netcamobilekeycomm/svrimplement/serverimplement.hpp"
#include "iniutilit.h"

#ifdef WIN32
#include <Windows.h>
#endif

#define SEVNAME_MAX 128
#ifndef MAX_PATH
#define MAX_PATH	260
#endif

typedef struct INIDATA{
    char szInetName[128];
    unsigned long dwInetPort;
	unsigned long dwLocalPort;
}INIDATA;

char s_szIniFile[MAX_PATH]= "/etc/netcamobilekeysvr.ini";

int main()
{
	int ret=0;
	//�õ�ini·��
#ifdef WIN32
	GetModuleFileName(NULL,s_szIniFile,sizeof(s_szIniFile)-1);
	strcpy(strchr(s_szIniFile, '.'), ".ini");
	WSADATA wsaData={0};
	WORD wSockVersion= MAKEWORD(1,1);
	WSAStartup(wSockVersion,&wsaData);
#endif
	printf("ini file:%s\r\n",s_szIniFile);
	//��ini
	INIDATA iniData = {0};
    ret = iniGetInt("Host", "Port", 9090, (int*)&iniData.dwLocalPort, s_szIniFile);
	if(ret)return ret;
    ret = iniGetString("Internat", "Name", "127.0.0.1", iniData.szInetName, SEVNAME_MAX-1, s_szIniFile);
	if(ret)return ret;
    ret = iniGetInt("Internat", "Port", 9090, (int*)&iniData.dwInetPort, s_szIniFile);
	if(ret)return ret;

	printf("read ini, Host.Port:%d, Internat.Name:%s, Internat.Port:%d\r\n",iniData.dwLocalPort,iniData.szInetName,iniData.dwInetPort);
	//��ʼ����
    P2PRelaySvrImpl svr;
    svr.SetInetIPP(iniData.szInetName, iniData.dwInetPort);
	printf("StartService...\r\n");
    if(svr.StartService(iniData.dwLocalPort))
		return 0;
}
