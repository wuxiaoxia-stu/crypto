#ifndef iniutilit_h
#define iniutilit_h

int iniGetString(const char *pszSection, const char *pszEntry, const char *pszDefault,
   char *pszRetBuf, unsigned int uiBufLen, const char *pszFileName);

int iniGetInt(const char *pszSection, const char *pszEntry, int lDefault,
   int *plVal, const char *pszFileName);


#endif
