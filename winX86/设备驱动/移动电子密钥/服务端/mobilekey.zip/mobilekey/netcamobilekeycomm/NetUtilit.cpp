/**
 * NETCA��Ȩ����2017
 * �ļ����ƣ� NetUtilt.cpp
 * �ļ�˵���� һЩ���繤�߷���
 * �汾��V1.0
 * ���ߣ�
 * ������ڣ�2017-07-17

 * ======= �޸ļ�¼ =========
 * �޸�˵����
 * �޸�ʱ�䣺
 * �޸��ˣ�
 */
#include "NetUtilt.h"
#include "Coder.h"
#ifdef WIN32
#include "../netcamobilekeyand/GlobalDefine.h"
#endif

/*��ȡ����MTU*/
DWORD GetMTU(SOCKET socket)
{
	//s.setsockopt(socket.IPPROTO_IP, IN.IP_MTU_DISCOVER, IN.IP_PMTUDISC_DO)
	return 1500;
}

#ifdef WIN32
void GetLocalIPs(std::vector<std::string> *ips,std::string *tarHostname){
	// ��ñ���������  
    char hostname[260] = {0};  
    gethostname(hostname,MAX_PATH);    
	*tarHostname = std::string(hostname);
    struct hostent FAR* lpHostEnt = gethostbyname(hostname);  
    if(lpHostEnt == NULL)  
    {  
		ips->push_back("127.0.0.1");  
		return ;
    }
	//sizeof(lpHostEnt->h_addr_list)/sizeof(lpHostEnt->h_addr_list[0])
	for (int i=0;;i++){
		LPSTR lpAddr = lpHostEnt->h_addr_list[i];        
  
		// ��IP��ַת�����ַ�����ʽ  
		struct in_addr inAddr;  
		memmove(&inAddr,lpAddr,4);  
        std::string s; 
		s.assign( inet_ntoa(inAddr) );
		ips->push_back(s);

		if (lpHostEnt->h_addr_list[i]+lpHostEnt->h_length>=lpHostEnt->h_name)
			break;
	}
}
#endif

std::string HexIpPortString(std::string strIP, unsigned short dwPort){
	unsigned long ip_16 = inet_addr(strIP.c_str());
	char ipHex[50];
	memset(ipHex,0,50);
	DWORD hexLength=sizeof(ipHex);
	char portHex[20];
	DWORD portLength;
	HexEncode((BYTE*)&ip_16,sizeof(DWORD),ipHex,&hexLength);
	sprintf(portHex, "%x", dwPort);
	//HexEncode((unsigned char *)&(dwPort),sizeof(unsigned short),portHex,&portLength);
	memcpy(ipHex+hexLength-1,":",1);
	memcpy(ipHex+hexLength,portHex,strlen(portHex));
	return ipHex;
}

std::string ToIpPortString(std::string ipportHex)
{
    if(ipportHex.length()==0) return "";
    //std::string ipHexStr = std::string(strtok((char *)ipportHex.c_str(), ":"));
    //std::string portHexStr = strtok(NULL, ":");

	int pos = ipportHex.find(":");
	if(pos == -1) return "";
	std::string portHexStr = ipportHex.substr(pos+1);
	std::string ipHexStr = ipportHex.substr(0,pos);
    unsigned long ip = strtoul(ipHexStr.c_str(), NULL, 16);
    
    //DWORD cbPort = 0;
    //HexDecode(portHexStr.c_str(), NULL, &cbPort);
    //unsigned char *pbPort = (unsigned char *)malloc(cbPort);
    //HexDecode(portHexStr.c_str(), pbPort, &cbPort);
    //unsigned short port = *(unsigned short *)pbPort;
    //free(pbPort);
    
    unsigned short port = strtol(portHexStr.c_str(), NULL, 16);
    char ipStr[32];
    unsigned char *p = (unsigned char *)&ip;
    sprintf(ipStr, "%d.%d.%d.%d", (int)p[3], (int)p[2], (int)p[1], (int)p[0]);

    char ipPortStr[50];
    sprintf(ipPortStr, "%s:%d", ipStr, port);
    return ipPortStr;
}


DWORD SetCommTmOut(SOCKET socket,DWORD dwTmOutSec)
{
#ifdef WIN32
	DWORD tmout= dwTmOutSec*1000;
#else
	timeval tmout = {dwTmOutSec,0};
#endif
	DWORD dwErr=0;
	int ret= setsockopt(socket,SOL_SOCKET,SO_RCVTIMEO,(char*)&tmout,sizeof(tmout));
    if(ret==SOCKET_ERROR)
        return WSAGetLastError();
	ret= setsockopt(socket,SOL_SOCKET,SO_SNDTIMEO,(char*)&tmout,sizeof(tmout));
    if(ret==SOCKET_ERROR)
        return WSAGetLastError();

	int nSendBuff = BUFF_SIZE;
	ret= setsockopt(socket,SOL_SOCKET,SO_SNDBUF,(const char*)&nSendBuff,sizeof(int));
	if(ret==SOCKET_ERROR)
        return WSAGetLastError();
	ret= setsockopt(socket,SOL_SOCKET,SO_RCVBUF,(const char*)&nSendBuff,sizeof(int));
	if(ret==SOCKET_ERROR)
        return WSAGetLastError();

	return 0;
}

DWORD CommSendAndRecv(SOCKET socket,const sockaddr_in* sendtoAddr,sockaddr_in* rcvfromAddrOut,const BYTE* bSend,DWORD cbSend,BYTE* bRecv,DWORD* pcbRecv)
{
	int ret=0;
	ret= sendto(socket,(char*)bSend,cbSend,0,(sockaddr*)sendtoAddr,sizeof(sockaddr_in));
	if(ret<=0)
	{
		#ifdef WIN32
		LOGD("sendto error");
		#endif
		return WSAGetLastError();
	}
	socklen_t addrlen= sizeof(sockaddr_in);
	ret= recvfrom(socket,(char*)bRecv,*pcbRecv,0,(sockaddr*)rcvfromAddrOut,&addrlen);
	if(ret<=0)
	{
		#ifdef WIN32
		LOGD("recvfrom error");
		#endif
		return WSAGetLastError();
	}

	*pcbRecv=(DWORD)ret;
	return 0;
}

BOOL CheckNetDownErr(DWORD dwErr)
{
	switch(dwErr)
	{
	case WSAECONNABORTED:	//close connection by myself
	case WSAECONNRESET:
	case WSAENOTSOCK:
		return TRUE;
	}
	return FALSE;
}