/**
 * NETCA版权所有2017
 * 文件名称：typedefine.h
 * 文件说明：本头文件用于在linux上实现一套和Windows一样的常用函数
 * 版本：V1.0
 * 作者：陈木来
 * 完成日期：2017-07-19

 * ======= 修改记录 =========
 * 修改说明：
 * 修改时间：
 * 修改人：
 */
#pragma once

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
//#include <asm/ioctls.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include "typedefine.h"

//错误码的替换，放到errorcode.h
extern "C"
{
    //事件方法的替换
    typedef struct HEVENT_stru {
        pthread_mutex_t		_mtx;
        pthread_cond_t		_cond;
    }*HEVENT;
    HEVENT CreateEvent(pthread_attr_t* lpEventAttributes, BOOL bManualReset, BOOL bInitialState, const char* lpName);
    DWORD WaitForSingleObject(HEVENT hHandle,DWORD dwMilliseconds);
    BOOL SetEvent(HEVENT hEvent);
    //BOOL ResetEvent(HEVENT hEvent);
    void DestroyEvent(HEVENT hHandle);
    
    //线程方法的替换
    typedef struct HTHREAD_stru {
        pthread_t	threadid;
    }*HTHREAD;
    typedef DWORD(WINAPI PTHREAD_START_ROUTINE)(void* lpThreadParameter);
    //创建并启动线程
    HTHREAD CreateThread(
                         const pthread_attr_t* lpThreadAttributes,
                         DWORD dwStackSize,
                         PTHREAD_START_ROUTINE *lpStartAddress,
                         void* lpParameter,
                         DWORD dwCreationFlags,
                         pthread_t* lpThreadId
                         );
    DWORD WaitForThreadFin(HTHREAD hHandle);
    void DestroyThread(HTHREAD hHandle);
}
