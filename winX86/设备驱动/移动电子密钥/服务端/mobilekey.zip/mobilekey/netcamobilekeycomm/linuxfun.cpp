/**
 * NETCA版权所有2017
 * 文件名称：typedefine.cpp
 * 文件说明：本文件用于在linux上实现一套和Windows一样的常用函数
 * 版本：V1.0
 * 作者：陈木来
 * 完成日期：2017-07-19

 * ======= 修改记录 =========
 * 修改说明：
 * 修改时间：
 * 修改人：
 */
#ifndef WIN32
//#include "../inc/RRSocket.h"
#include "linuxfun.h"

HEVENT CreateEvent(pthread_attr_t* lpEventAttributes, BOOL bManualReset, BOOL bInitialState, const char* lpName)
{
    HEVENT hEvent = new HEVENT_stru();
    pthread_mutex_init(&hEvent->_mtx, 0);
    pthread_cond_init(&hEvent->_cond, 0);
    return hEvent;
}
void DestroyEvent(HEVENT hHandle)
{
    if (!hHandle)return;
    pthread_mutex_destroy(&hHandle->_mtx);
    pthread_cond_destroy(&hHandle->_cond);
    delete hHandle;
}
BOOL SetEvent(HEVENT hEvent)
{
    if (!hEvent)return FALSE;
    pthread_mutex_lock(&hEvent->_mtx);
    pthread_cond_signal(&hEvent->_cond);
    pthread_mutex_unlock(&hEvent->_mtx);
    return TRUE;
}
DWORD WaitForSingleObject(HEVENT hHandle, DWORD dwMilliseconds)
{
    int ret = 0;
    if (dwMilliseconds == 0) // no time for waiting
        return WAIT_TIMEOUT;
    if (dwMilliseconds == INFINITE)
    {
        pthread_mutex_lock(&hHandle->_mtx);
        ret = pthread_cond_wait(&hHandle->_cond, &hHandle->_mtx);
        pthread_mutex_unlock(&hHandle->_mtx);
    }
    else
    {
        timespec timeout_ = { 0 };
        // set timeout
        timeval now_;
        gettimeofday(&now_, 0);
        timeout_.tv_sec = now_.tv_sec + dwMilliseconds / 1000;
        timeout_.tv_nsec = (((dwMilliseconds % 1000) * 1000 + now_.tv_usec) % 1000000) * 1000;
        pthread_mutex_lock(&hHandle->_mtx);
        ret = pthread_cond_timedwait(&hHandle->_cond, &hHandle->_mtx, &timeout_);
        pthread_mutex_unlock(&hHandle->_mtx);
    }
    
    // adjust signaled member
    switch (ret)
    {
        case 0: // success
            return WAIT_OBJECT_0;
        case ETIMEDOUT:
        default:
            return WAIT_TIMEOUT;
    }
}

HTHREAD CreateThread(
                     const pthread_attr_t* lpThreadAttributes,
                     DWORD dwStackSize,
                     PTHREAD_START_ROUTINE *lpStartAddress,
                     void* lpParameter,
                     DWORD dwCreationFlags,
                     pthread_t* lpThreadId)
{
    pthread_t thrdID = 0;
    if (lpThreadId == NULL)
        lpThreadId = &thrdID;
    void *(*start_routine)(void *) = (void *(*)(void *))lpStartAddress;
    int ret = pthread_create(lpThreadId, lpThreadAttributes, start_routine, lpParameter);
    if (ret)
        return NULL;
    pthread_detach(*lpThreadId);
    
    HTHREAD handle = new HTHREAD_stru();
    handle->threadid = *lpThreadId;
    return handle;
}

//等待线程结束
DWORD WaitForThreadFin(HTHREAD hHandle)
{
    if (!hHandle)return 0;
    pthread_join(hHandle->threadid, NULL);
    return 0;
}

void DestroyThread(HTHREAD hHandle)
{
    if (!hHandle)return;
    delete hHandle;
}

#endif
