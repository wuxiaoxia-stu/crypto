/**
 * NETCA��Ȩ����2017
 * �ļ����ƣ�encryptor_ecaessha_impl.cpp
 * �ļ�˵����encryptor��ECIES_AES256CBC_SHA256ʵ��
 * �汾��V1.0
 * ���ߣ���ľ��
 * ������ڣ�2017-03-21

 * ======= �޸ļ�¼ =========
 * �޸�˵����
 * �޸�ʱ�䣺
 * �޸��ˣ�
 */
#pragma once
#include "encryptor.h"
#include <openssl/hmac.h>


#define DEFAULT_CIPHERSUITE	"ECDHE_AES256CBC_SHA256"

class AES256SHA256_Encryptor : public AbstractEncryptor
{
private:
	BYTE* m_pbSk;
	DWORD m_cbSk;	//32 bytes
	BYTE* m_pbIV;
	DWORD m_cbIV;	//16 bytes
	BYTE* m_pbHk;
	DWORD m_cbHk;	//16 bytes

#if OPENSSL_VERSION_NUMBER < 0x10100000L
	HMAC_CTX m_hmac_ctx;
#else
	HMAC_CTX *m_hmac_ctx;
#endif
	//HMAC_CTX *m_hmac_ctx;
public:
	AES256SHA256_Encryptor(BYTE* pbSk,DWORD cbSk,BYTE* pbIV,DWORD cbIV,BYTE* pbHk,DWORD cbHk);
	~AES256SHA256_Encryptor();
	const BYTE* GetHk();
	DWORD GetHkLen();
	virtual DWORD GetMACLength();
	virtual DWORD MACInit();
	virtual DWORD MACUpdate(const BYTE* pbData, DWORD cbData);
	virtual DWORD MACFinal(const BYTE* pbData, DWORD cbData, BYTE* pbHMAC, DWORD *pcbHMAC);
	virtual DWORD GetEncryptLen(DWORD cbData);
	virtual DWORD EncryptData(const BYTE* pbData, DWORD cbData, BYTE* pbCipher, DWORD* pcbCipher);
	virtual DWORD GetDecryptLen(DWORD cbCipher);
	virtual DWORD DecryptData(const BYTE* pbCipher, DWORD cbCipher, BYTE* pbData, DWORD* pcbData);
};

class ECDHE_PCEncryptor : public PCEncryptor
{
private:
	static const DWORD s_PSK_LEN=65;
	HECKEY m_hkeypair;	//˽Կ
	AES256SHA256_Encryptor* m_pabsencryptor;

public:
	ECDHE_PCEncryptor();
	~ECDHE_PCEncryptor();
	DWORD ReNegotiate(const char* szCiperSuite);
	DWORD GenPSk(BYTE* pbPSk, DWORD* pcbPSk);
	DWORD AcceptMobileKeyExchange(const BYTE* pbMobileKeyExch, DWORD cbMobileKeyExch);
	DWORD GenPCKeyExchange(BYTE* pbPCKeyExch, DWORD *pcbPCKeyExch);
	DWORD AcceptFinish(const BYTE* pbFinish, DWORD cbFinish);
	DWORD GetMACLength();
	DWORD MACInit();
	DWORD MACUpdate(const BYTE* pbData, DWORD cbData);
	DWORD MACFinal(const BYTE* pbData, DWORD cbData, BYTE* pbHMAC, DWORD *pcbHMAC);
	DWORD GetEncryptLen(DWORD cbData);
	DWORD EncryptData(const BYTE* pbData, DWORD cbData, BYTE* pbCipher, DWORD* pcbCipher);
	DWORD GetDecryptLen(DWORD cbCipher);
	DWORD DecryptData(const BYTE* pbCipher, DWORD cbCipher, BYTE* pbData, DWORD* pcbData);
};

class ECDHE_MobileEncryptor : public MobileEncryptor
{
private:
	static const DWORD s_PSK_LEN=65;
	HECKEY m_hkeypair;	//��Կ
	AES256SHA256_Encryptor* m_pabsencryptor;
public:
	ECDHE_MobileEncryptor();
	~ECDHE_MobileEncryptor();
	DWORD ReNegotiate(const char* szCiperSuite);
	DWORD AcceptPSk(const BYTE* pbPSk, DWORD cbPSk);
	DWORD GenMobileKeyExchange(BYTE* pbMobileKeyExch, DWORD *pcbMobileKeyExch);
	DWORD AcceptPCKeyExchange(const BYTE* pbPCKeyExch, DWORD cbPCKeyExch);
	DWORD GenFinish(BYTE* pbFinish, DWORD* pcbFinish);
	DWORD GetMACLength();
	DWORD MACInit();
	DWORD MACUpdate(const BYTE* pbData, DWORD cbData);
	DWORD MACFinal(const BYTE* pbData, DWORD cbData, BYTE* pbHMAC, DWORD *pcbHMAC);
	DWORD GetEncryptLen(DWORD cbData);
	DWORD EncryptData(const BYTE* pbData, DWORD cbData, BYTE* pbCipher, DWORD* pcbCipher);
	DWORD GetDecryptLen(DWORD cbCipher);
	DWORD DecryptData(const BYTE* pbCipher, DWORD cbCipher, BYTE* pbData, DWORD* pcbData);
};

unsigned long GetOpenSslErr();
