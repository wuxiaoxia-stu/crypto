/**
 * NETCA��Ȩ����2017
 * �ļ����ƣ�encryptor_ecaessha_impl.cpp
 * �ļ�˵����encryptor��ECIES_AES256CBC_SHA256ʵ��
 * �汾��V1.0
 * ���ߣ���ľ��
 * ������ڣ�2017-03-21

 * ======= �޸ļ�¼ =========
 * �޸�˵����
 * �޸�ʱ�䣺
 * �޸��ˣ�
 */

#include "encryptor_ecaessha_impl.h"
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include "../errorcode.h"
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/err.h>
#include "ecies.h"


AES256SHA256_Encryptor::AES256SHA256_Encryptor(BYTE* pbSk,DWORD cbSk,BYTE* pbIV,DWORD cbIV,BYTE* pbHk,DWORD cbHk)
	:m_pbSk(NULL)
	,m_cbSk(cbSk)
	,m_pbIV(NULL)
	,m_cbIV(cbIV)
	,m_pbHk(NULL)
	,m_cbHk(cbHk)
{
	if(pbSk && cbSk)
	{
		m_pbSk= (BYTE*)malloc(m_cbSk);
		memcpy(m_pbSk,pbSk,m_cbSk);
	}
	if(pbIV && cbIV)
	{
		m_pbIV= (BYTE*)malloc(m_cbIV);
		memcpy(m_pbIV,pbIV,m_cbIV);
	}
	if(pbHk && cbHk)
	{
		m_pbHk= (BYTE*)malloc(m_cbHk);
		memcpy(m_pbHk,pbHk,m_cbHk);
	}
}
AES256SHA256_Encryptor::~AES256SHA256_Encryptor()
{
	//if(m_hmac_ctx)
	//	HMAC_CTX_cleanup(m_hmac_ctx);

	if(m_pbSk)free(m_pbSk);
	if(m_pbIV)free(m_pbIV);
	if(m_pbHk)free(m_pbHk);
}
const BYTE* AES256SHA256_Encryptor::GetHk()
{
	return m_pbHk;
}
DWORD AES256SHA256_Encryptor::GetHkLen()
{
	return m_cbHk;
}
DWORD AES256SHA256_Encryptor::GetMACLength()
{
	return 32;
}
DWORD AES256SHA256_Encryptor::MACInit()
{
	if(!m_pbHk)
		return NTE_NO_KEY;
	int ret=0;
	//HMAC_CTX_cleanup(&m_hmac_ctx);
#if OPENSSL_VERSION_NUMBER < 0x10100000L
	HMAC_CTX_init(&m_hmac_ctx);
	ret= HMAC_Init_ex(&m_hmac_ctx,m_pbHk,m_cbHk,EVP_sha256(),NULL);
#else
    HMAC_CTX_reset(m_hmac_ctx);
	ret= HMAC_Init_ex(m_hmac_ctx,m_pbHk,m_cbHk,EVP_sha256(),NULL);
#endif
    
	if(!ret)
		return GetOpenSslErr();

	//if(pcbHMAC)
	//	*pcbHMAC= HMAC_size(&m_hmac_ctx);	//32;
	return NOERROR;
}
DWORD AES256SHA256_Encryptor::MACUpdate(const BYTE* pbData, DWORD cbData)
{
	int ret=0;

#if OPENSSL_VERSION_NUMBER < 0x10100000L
	ret= HMAC_Update(&m_hmac_ctx,pbData,cbData);
#else
    ret= HMAC_Update(m_hmac_ctx,pbData,cbData);
#endif
	if(!ret)
		return GetOpenSslErr();

	return NOERROR;
}
DWORD AES256SHA256_Encryptor::MACFinal(const BYTE* pbData, DWORD cbData, BYTE* pbHMAC, DWORD *pcbHMAC)
{
	int ret=0;
	DWORD dwErr=0;

#if OPENSSL_VERSION_NUMBER < 0x10100000L
	ret= HMAC_Update(&m_hmac_ctx,pbData,cbData);
#else
    ret= HMAC_Update(m_hmac_ctx,pbData,cbData);
#endif
	if(!ret)
		dwErr= GetOpenSslErr();
	else
	{
#if OPENSSL_VERSION_NUMBER < 0x10100000L
		ret= HMAC_Final(&m_hmac_ctx, pbHMAC, (unsigned int*)pcbHMAC);
#else
		ret= HMAC_Final(m_hmac_ctx, pbHMAC, (unsigned int*)pcbHMAC);
#endif
		if(!ret)
			dwErr= GetOpenSslErr();
	}
#if OPENSSL_VERSION_NUMBER < 0x10100000L
	HMAC_CTX_cleanup(&m_hmac_ctx);
#else
    HMAC_CTX_free(m_hmac_ctx);
#endif

	return dwErr;
}
DWORD AES256SHA256_Encryptor::GetEncryptLen(DWORD cbData)
{
	return cbData+16;
}
DWORD AES256SHA256_Encryptor::EncryptData(const BYTE* pbData, DWORD cbData, BYTE* pbCipher, DWORD* pcbCipher)
{
	if(!pbData || !cbData || !pcbCipher)
		return ERROR_BAD_ARGUMENTS;
	if(!m_pbSk || !m_pbIV)
		return NTE_NO_KEY;

	if(pbCipher==NULL)
	{
		*pcbCipher= cbData+16;
		return NOERROR;
	}
	else if(*pcbCipher<cbData+16)
	{
		*pcbCipher= cbData+16;
		return NTE_BUFFER_TOO_SMALL;
	}
		
	int ret;
	int len;
	EVP_CIPHER_CTX *ctx= EVP_CIPHER_CTX_new();
	const EVP_CIPHER *evp_cipher= EVP_aes_256_cbc();
	ret= EVP_EncryptInit_ex(ctx,evp_cipher,NULL,m_pbSk,m_pbIV);
	if(1!=ret)return GetOpenSslErr();
	ret= EVP_EncryptUpdate(ctx,pbCipher,&len,pbData,cbData);
	if(1!=ret)return GetOpenSslErr();
	*pcbCipher= len;
	ret= EVP_EncryptFinal_ex(ctx,pbCipher+len,&len);
	if(1!=ret)return GetOpenSslErr();
	*pcbCipher+= len;
	EVP_CIPHER_CTX_free(ctx);
	return NOERROR;
}
DWORD AES256SHA256_Encryptor::GetDecryptLen(DWORD cbCipher)
{
	return cbCipher;
}
DWORD AES256SHA256_Encryptor::DecryptData(const BYTE* pbCipher, DWORD cbCipher, BYTE* pbData, DWORD* pcbData)
{
	if(!pbCipher || !cbCipher || !pcbData)
		return ERROR_BAD_ARGUMENTS;

	if(pbData==NULL)
	{
		*pcbData= cbCipher;
		return NOERROR;
	}
	else if(*pcbData<cbCipher)
	{
		*pcbData= cbCipher;
		return NTE_BUFFER_TOO_SMALL;
	}
		
	int ret;
	int len;
	EVP_CIPHER_CTX *ctx= EVP_CIPHER_CTX_new();
	const EVP_CIPHER *evp_cipher= EVP_aes_256_cbc();
	ret= EVP_DecryptInit_ex(ctx,evp_cipher,NULL,m_pbSk,m_pbIV);
	if(1!=ret)return GetOpenSslErr();
	ret= EVP_DecryptUpdate(ctx,pbData,&len,pbCipher,cbCipher);
	if(1!=ret)return GetOpenSslErr();
	*pcbData= len;
	ret= EVP_DecryptFinal_ex(ctx,pbData+len,&len);
	if(1!=ret)return GetOpenSslErr();
	*pcbData+= len;
	EVP_CIPHER_CTX_free(ctx);
	return NOERROR;
}

unsigned long GetOpenSslErr()
{
	unsigned long ret=0;
	const char* file=NULL;
	int line=0;
	const char* data=NULL;
	int flags=0;
	ret= ERR_get_error_line_data(&file, &line, &data, &flags);
	return ret;
}

#if 0
class ECDHE_AES256SHA256_EncryptorFactory : public EncryptorFactory
{
private:
	ECDHE_PCEncryptor m_pcencryptor;
	ECDHE_MobileEncryptor m_mobileencryptor;
public:
    PCEncryptor* GetPCEncryptorInstance()
	{
		return &m_pcencryptor;
	}
    MobileEncryptor* GetMobileEncryptorInstance()
	{
		return &m_mobileencryptor;
	}
};

ECDHE_AES256SHA256_EncryptorFactory g_factory;

EncryptorFactory* GetEncryptorFactoryInstance()
{
	return (EncryptorFactory*)&g_factory;
}
#endif
