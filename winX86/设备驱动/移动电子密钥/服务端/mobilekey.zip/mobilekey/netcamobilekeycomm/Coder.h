#ifndef CODER_H
#define CODER_H

#ifndef WIN32
#include "typedefine.h"
#endif

#ifdef __cplusplus
extern "C"{
#endif


void NativeBytesToNetBytes(BYTE* byteArray/*in out*/,DWORD len);

DWORD HexEncode(BYTE* pbIn,DWORD cbIn,char* pszHex/*out*/,DWORD *pdwOut/*in out*/);
DWORD HexDecode(const char* szHex,BYTE* pbOut,DWORD *pcbOut/*in out*/);

DWORD Base64Encode(const BYTE *pbIn,DWORD cbIn,/*out*/char *pchOut,/*out*/DWORD *pcchOut);
DWORD Base64Decode(const char *pchIn,DWORD cchIn,/*out*/BYTE *pbOut,/*out*/DWORD *pcbOut);

#if 0
//free outer
char* __stdcall UnicodeToGBK(const wchar_t* wszIn);
wchar_t* __stdcall GBKToUnicode(const char* szIn);
char* __stdcall UnicodeToUTF8(const wchar_t* wszIn);
wchar_t* __stdcall UTF8ToUnicode(const char* szIn);
char* __stdcall GBKToUTF8(const char* szGBK);
char* __stdcall UTF8ToGBK(const char* szUTF8);
#endif

#ifdef __cplusplus
}
#endif

#endif
