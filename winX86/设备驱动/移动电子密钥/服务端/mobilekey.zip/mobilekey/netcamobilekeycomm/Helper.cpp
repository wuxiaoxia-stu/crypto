#include "Helper.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#ifndef MAX_PATH
#define MAX_PATH 256
#endif

char s_szLogFile[MAX_PATH]= "./commlayer.log";


#ifdef _DEBUG
const int s_isLog=1;
#else
const int s_isLog=0;
#endif

//void IntToHex(const unsigned char *pbInt,int cbInt,unsigned char *pbHex)
//{
//	if(pbInt==NULL || cbInt==0 || pbHex==NULL)return;
//
//	static char cDig[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
//
//	for(int i=0;i<cbInt;i++)
//	{
//		unsigned char pos;
//		pos= (pbInt[i]>>4)&0x0F;
//		pbHex[2*i]= cDig[pos];
//		pos= pbInt[i]&0x0F;
//		pbHex[2*i+1]= cDig[pos];
//	}
//}
//
//static void LogToFile(const char* szMsg)
//{
//	if(!szMsg)return;
//	try{
//	//>>enter critical section
//	FILE* fp= fopen(s_szLogFile,"a+");
//	if(fp==NULL)return;
//	fwrite(szMsg,strlen(szMsg),1,fp);
//	fclose(fp);
//	//>>leave critical section
//#ifdef ANDROID_NDK
//	chmod(s_szLogFile,0x644);
//#endif
//	}catch(...){}
//}
//
//void LogInfoData(const char* pszHdr, unsigned char bData[], int nDataLen)
//{
//	if(!s_isLog)return;
//	//format message: hdr:\r\ndata\r\n
//	if(pszHdr==NULL)pszHdr="";
//	int len= (int)strlen(pszHdr);
//	int cbMsg= len+8+2*nDataLen;
//	char* szMsg= (char*)malloc(cbMsg);
//	memset(szMsg,0,cbMsg);
//	memcpy(szMsg,pszHdr,len);
//	memcpy(szMsg+len,":\r\n",3);
//	len+=3;
//	IntToHex(bData,nDataLen,(unsigned char*)szMsg+len);
//	len+=nDataLen*2;
//	memcpy(szMsg+len,"\r\n",2);
//	len+=2;
//	szMsg[len]=0;
//	//write
//	LogToFile(szMsg);
//	free(szMsg);
//}
//
//void LogInfoStr(const char* pszHdr, const char* pszInfo)
//{
//	if(!s_isLog)return;
//	//format message: hdr:\r\ndata\r\n
//	if(pszHdr==NULL)pszHdr="";
//	if(pszInfo==NULL)pszInfo="";
//	int len= (int)strlen(pszHdr)+ (int)strlen(pszInfo)+ 8;
//	char* szMsg= (char*)malloc(len);
//	memset(szMsg,0,len);
//	sprintf(szMsg, "%s:\r\n%s\r\n", pszHdr,pszInfo);
//	//wriet
//	LogToFile(szMsg);
//	free(szMsg);
//}
//
//void LogInfo(const char* pszInfo)
//{
//	if(!s_isLog)return;
//	if(pszInfo==NULL)return;
//	//format message: hdr:\r\ndata\r\n
//	int len= (int)strlen(pszInfo)+8;
//	char* szMsg= (char*)malloc(len);
//	memset(szMsg,0,len);
//	sprintf(szMsg, "%s\r\n", pszInfo);
//	//wriet
//	LogToFile(szMsg);
//	free(szMsg);
//}
//free outer
unsigned char* ReadWholeFile(const char* szFilePath,unsigned long* pcbData)
{
	FILE* fp= fopen(szFilePath,"r");
	if(fp==NULL)return NULL;
	fseek(fp,SEEK_SET,SEEK_END);
	*pcbData=ftell(fp);
	unsigned char* pbData= (unsigned char*)malloc(*pcbData+1);
	memset(pbData,0,*pcbData+1);
	fseek(fp,SEEK_SET,SEEK_SET);
	fread(pbData,*pcbData,1,fp);
	fclose(fp);
//	pbData[*pcbData]=0;
	return pbData;
}
int WriteToFile(const char* szFilePath,unsigned char* pbData,unsigned long cbData)
{
	FILE* fp= fopen(szFilePath,"w");
	if(fp==NULL)return 0;
	fwrite(pbData,cbData,1,fp);
	fclose(fp);
	return 1;
}
