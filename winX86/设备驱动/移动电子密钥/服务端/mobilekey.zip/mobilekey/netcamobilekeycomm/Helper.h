#ifndef HELPER_H
#define HELPER_H

#ifdef __cplusplus
extern "C"{
#endif

//void LogInfoData(const char* pszHdr, unsigned char bData[], int nDataLen);
//void LogInfoStr(const char* pszHdr, const char* pszInfo);
//void LogInfo(const char* pszInfo);

//free outer
unsigned char* ReadWholeFile(const char* szFilePath,unsigned long* pcbData);
//0: failed; 1: ok
int WriteToFile(const char* szFilePath,unsigned char* pbData,unsigned long cbData);

#ifdef __cplusplus
}
#endif

#endif
