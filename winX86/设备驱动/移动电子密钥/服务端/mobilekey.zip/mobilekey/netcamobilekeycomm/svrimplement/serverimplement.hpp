#ifndef serverimpletement_hpp
#define serverimpletement_hpp

#include <string>
#include "../typedefine.h"
#include "../commlayer.h"

class P2PRelaySvrImpl:public P2PRelaySvr{
private:
	sockaddr_in m_my_raddr;		//����������ַ
	//����Ƿ�Ϸ���ת����ַ
	BOOL CheckRelayAddr(const sockaddr_in* fromaddr, const sockaddr_in* toaddr);
public:
    virtual void SetInetIPP(const char* szSev, DWORD dwPort);
    virtual DWORD StartService(DWORD dwPort);
    virtual void StopService();
};

#endif /* serverimpletement_hpp */
