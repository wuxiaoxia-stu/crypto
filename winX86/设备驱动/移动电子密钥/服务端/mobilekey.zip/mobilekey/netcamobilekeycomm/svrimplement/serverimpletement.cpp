/**
 * NETCA��Ȩ����2017
 * �ļ����ƣ�serverimpletement.hpp
 * �ļ�˵������ת������ʵ��
 * �汾��V1.0
 * ���ߣ�
 * ������ڣ�2017-07-22

 * ======= �޸ļ�¼ =========
 * �޸�˵����
 * �޸�ʱ�䣺
 * �޸��ˣ���ľ��
 */

#ifdef WIN32
#include <Ws2tcpip.h>
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#endif
#include <time.h>
#include "serverimplement.hpp"
#include "../NetUtilt.h"
#include "../PackParse.h"
#include "../../jsoncpp/inc/json.h"
#include "../encryptor/encryptor_ecaessha_impl.h"

using namespace std;
#define BUFF_SIZE	1024*10

static const char* GetDateTiemStr()
{
	static char buf[128]= {0};  
	time_t t;  //��ʱ��  
	tm* local; //����ʱ��   
  
	t = time(NULL); //��ȡĿǰ��ʱ��  
	local = localtime(&t); //תΪ����ʱ��  
	strftime(buf, 64, "%Y-%m-%d %H:%M:%S", local);  

	return buf;
}
BOOL P2PRelaySvrImpl::CheckRelayAddr(const sockaddr_in* fromaddr, const sockaddr_in* toaddr)
{
	//����ַ��Ч��
	sockaddr_in chkaddr={0};
	//ȫ����ַ
	if(memcmp(&toaddr->sin_addr,&chkaddr.sin_addr,sizeof(chkaddr.sin_addr))==0 || toaddr->sin_port==0)
		return FALSE;
	//Դ��Ŀ����ͬ
	if(memcmp(&toaddr->sin_addr,&fromaddr->sin_addr,sizeof(fromaddr->sin_addr))==0 && toaddr->sin_port==fromaddr->sin_port)
		return FALSE;
	//�ͱ�����ַ��ͬ
	if(memcmp(&toaddr->sin_addr,&m_my_raddr.sin_addr,sizeof(m_my_raddr.sin_addr))==0 && toaddr->sin_port==m_my_raddr.sin_port)
		return FALSE;
	//>>�㲥��ಥ��ַ...
	//!!!��õķ�������һ��map����¼��Щ�Ϸ��ĵ�ַ�ԣ�����SYN/ACK/FIN�������Ե�ַ��״̬�����޸�

	return TRUE;
}

void P2PRelaySvrImpl::SetInetIPP(const char *szSev, DWORD dwPort){
	m_my_raddr.sin_family= AF_INET;
	inet_pton(AF_INET, szSev, &m_my_raddr.sin_addr);
	m_my_raddr.sin_port= htons((WORD)dwPort);
}

void P2PRelaySvrImpl::StopService()
{
}

DWORD P2PRelaySvrImpl::StartService(DWORD dwPort)
{
	int ret=0;
	DWORD dwErr=0;
	//opensocket and bind
	sockaddr_in my_addr= {0};
	my_addr.sin_family = AF_INET;
	my_addr.sin_addr.s_addr=htonl(INADDR_ANY);
	my_addr.sin_port = htons((WORD)dwPort);
	
	SOCKET sockComm= socket(AF_INET,SOCK_DGRAM,0);
    if(sockComm==INVALID_SOCKET)
        return WSAGetLastError();
	printf("socket opened\r\n");
	ret= bind(sockComm,(struct sockaddr*)&my_addr,sizeof(my_addr));
    if(ret==SOCKET_ERROR)
    {
        dwErr=WSAGetLastError();
		closesocket(sockComm);
        return dwErr;
    }
	printf("port binded:%d\r\n",dwPort);

	PackParse parse(NULL);
	while(1)
	{
		//recv data
		BYTE bRcvBuff[BUFF_SIZE]={0};
		DWORD cbRcvBuff=sizeof(bRcvBuff);
		sockaddr_in fromaddr={0};
		socklen_t addrlen= sizeof(sockaddr_in);
		ret= recvfrom(sockComm,(char*)bRcvBuff,cbRcvBuff,0,(sockaddr*)&fromaddr,&addrlen);

		printf("[%s] recv data,len:%d. from:%s:%d\r\n",GetDateTiemStr(),ret,inet_ntoa(fromaddr.sin_addr),ntohs(fromaddr.sin_port));
		if(ret<=0)
		{
			dwErr= WSAGetLastError();
			if(CheckNetDownErr(dwErr))	//close connection by myself
				break;
			if(dwErr==WSAETIMEDOUT||dwErr==EAGAIN)	//time out
				continue;
			//��������ʱ��������
			continue;
		}
		cbRcvBuff= ret;
		//��������
		BYTE msgtype=0;
		BOOL isRelay=FALSE;
		sockaddr_in relayTo={0};
		dwErr= parse.ParseMsgHdr(bRcvBuff,cbRcvBuff,&isRelay,NULL,&relayTo,&msgtype,NULL,NULL,NULL,NULL);
		if(dwErr)
			continue;
		printf("Parsed Message,msgtype:0x%02x. isRelay:%d\r\n",msgtype,isRelay);
		if(msgtype==0x01)	//��ѯRIPP����
		{
			Json::Value value;
			value["errcode"] = 0;
			value["RIP"] =  inet_ntoa(fromaddr.sin_addr);
			value["RPort"] = ntohs(fromaddr.sin_port);
			value["SIP"] =  inet_ntoa(m_my_raddr.sin_addr);
			value["SPort"] = ntohs(m_my_raddr.sin_port);
			Json::FastWriter writer;
			std::string jsonString = writer.write(value);
			//������Ӧ��
			BYTE bSndBuff[BUFF_SIZE]={0};
			DWORD cbSndBuff=sizeof(bSndBuff);
			dwErr= parse.PackMessage(bSndBuff,&cbSndBuff,FALSE,NULL,0x81,FALSE,FALSE,jsonString.length(),(BYTE*)jsonString.c_str());
			if(dwErr)
				continue;
			printf("RIPP response,len:%d\r\n",cbSndBuff);
			ret= sendto(sockComm,(char*)bSndBuff,cbSndBuff,0,(sockaddr*)&fromaddr,addrlen);
			if(ret<=0)
				dwErr= WSAGetLastError();
		}
		else if(isRelay)
		{
			//����ַ��Ч��
			if(!CheckRelayAddr(&fromaddr,&relayTo))
				continue;
			//����Դ��ַ
			dwErr= parse.RelayPackMessage(bRcvBuff,cbRcvBuff,&fromaddr);
			if(dwErr)
				continue;

			//���͵�Ŀ�ĵ�ַ
			relayTo.sin_family= AF_INET;
			ret= sendto(sockComm,(char*)bRcvBuff,cbRcvBuff,0,(sockaddr*)&relayTo,sizeof(relayTo));
			printf("relay to:%s:%d\r\n",inet_ntoa(relayTo.sin_addr),ntohs(relayTo.sin_port));
			if(ret<=0)
				dwErr= WSAGetLastError();
		}
	}

	//relase
	closesocket(sockComm);
	printf("socket closed\r\n");
	return dwErr;
}
