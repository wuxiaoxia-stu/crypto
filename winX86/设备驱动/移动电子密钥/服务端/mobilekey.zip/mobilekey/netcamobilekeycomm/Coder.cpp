#include "typedefine.h"
#include "errorcode.h"
#include "Coder.h"
#include <stdlib.h>
#include <string.h>

#define min(a,b)    (((a) < (b)) ? (a) : (b))

void NativeBytesToNetBytes(BYTE* byteArray,DWORD len)
{
	DWORD i;
	BYTE swap;

	if(byteArray==NULL||len==0)return;

	DWORD nTest= 0x01020304;
	BYTE* pbTest= (BYTE*)&nTest;
	if(pbTest[0]==0x01)return;	//big endian

	for(i=0;i<len/2;i++)
	{
		swap=byteArray[i];
		byteArray[i]=byteArray[len-1-i];
		byteArray[len-1-i]=swap;
	}
}

static BYTE HexCharToInt(char in)
{
	if(in<='9'&&in>='0')return (BYTE)(in-'0');
	if(in<='f'&&in>='a')return (BYTE)(in-'a'+10);
	if(in<='F'&&in>='A')return (BYTE)(in-'A'+10);
	return 0;
}

DWORD HexEncode(BYTE* pbIn,DWORD cbIn,char* pszOut,DWORD *pdwOut/*in out*/)
{
	DWORD i;
	static char sDig[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	if(!pbIn || !cbIn || !pdwOut)return E_INVALIDARG;
	if(!pszOut){
		*pdwOut=2*cbIn+1;
		return NOERROR;
	}
	if(*pdwOut<2*cbIn+1){
		*pdwOut=2*cbIn+1;
		return ERROR_MORE_DATA;
	}

	BYTE* in=pbIn;
	char* out=pszOut;
	for(i=0;i<cbIn;i++){
		*out=sDig[(*in>>4)&0x0F];
		out++;
		*out=sDig[*in&0x0F];
		out++;
		in++;
	}
	pszOut[2*cbIn]='\0';
	*pdwOut=2*cbIn+1;
	return NOERROR;
}

DWORD HexDecode(const char* szHexStr,BYTE* pbOut,DWORD *pcbOut/*in out*/)
{
	DWORD i;
	int strLen= strlen(szHexStr);
	DWORD outLen=strLen/2+strLen%2;

	if(szHexStr==NULL)return E_INVALIDARG;
	if(pbOut==NULL){
		*pcbOut=outLen;
		return NOERROR;
	}
	if(*pcbOut<outLen){
		*pcbOut=outLen;
		return ERROR_MORE_DATA;
	}
	const char* in=szHexStr;
	BYTE* out=pbOut;
	i=0;
	if(strLen%2){
		*out=HexCharToInt(*in);
		out++;in++;i++;
	}
	for(;i<outLen;i++){
		*out=HexCharToInt(*in)<<4;
		in++;
		*out+=HexCharToInt(*in);
		in++;
		out++;
	}
	*pcbOut=outLen;
	return NOERROR;
}


// The following table translates an ascii subset to 6 bit values as follows
// (see rfc 1521):
//
//  input    hex (decimal)
//  'A' --> 0x00 (0)
//  'B' --> 0x01 (1)
//  ...
//  'Z' --> 0x19 (25)
//  'a' --> 0x1a (26)
//  'b' --> 0x1b (27)
//  ...
//  'z' --> 0x33 (51)
//  '0' --> 0x34 (52)
//  ...
//  '9' --> 0x3d (61)
//  '+' --> 0x3e (62)
//  '/' --> 0x3f (63)
//
// Encoded lines must be no longer than 76 characters.
// The final "quantum" is handled as follows:  The translation output shall
// always consist of 4 characters.  'x', below, means a translated character,
// and '=' means an equal sign.  0, 1 or 2 equal signs padding out a four byte
// translation quantum means decoding the four bytes would result in 3, 2 or 1
// unencoded bytes, respectively.
//
//  unencoded size    encoded data
//  --------------    ------------
//     1 byte		"xx=="
//     2 bytes		"xxx="
//     3 bytes		"xxxx"

#ifdef assert
# define CSASSERT assert
#else
#define CSASSERT(x) DBGCHK(TEXT("BASE64"),x)
#define DBGCHK(a,b)
#endif

#define CB_BASE64LINEMAX	64	// others use 64 -- could be up to 76

// Any other (invalid) input character value translates to 0x40 (64)

const BYTE abDecode[256] =
{
    /* 00: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* 10: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* 20: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63,
    /* 30: */ 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64,
    /* 40: */ 64,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    /* 50: */ 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64,
    /* 60: */ 64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    /* 70: */ 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64,
    /* 80: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* 90: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* a0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* b0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* c0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* d0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* e0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    /* f0: */ 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
};


const char abEncode[] =
{
    /*  0 thru 25: */ 'A','B','C','D','E','F','G','H','I','J','K','L','M','N',
	'O','P','Q','R','S','T','U','V','W','X','Y','Z',
    /* 26 thru 51: */ 'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
	'o','p','q','r','s','t','u','v','w','x','y','z',
    /* 52 thru 61: */ '0','1','2','3','4','5','6','7','8','9',
    /* 62 and 63: */  '+','/'
};


DWORD			// ERROR_*
Base64Decode(
    char const *pchIn,
    DWORD cchIn,
    BYTE *pbOut,
    DWORD *pcbOut)
{
	DWORD *pchConsumed= NULL;
    DWORD err = NOERROR;
    DWORD cchInDecode, cbOutDecode;
    char const *pchInEnd;
    char const *pchInT;
    BYTE *pbOutT;

    // Count the translatable characters, skipping whitespace & CR-LF chars.

    cchInDecode = 0;
    pchInEnd = &pchIn[cchIn];
    for (pchInT = pchIn; pchInT < pchInEnd; pchInT++)
    {
	if (sizeof(abDecode) < (unsigned) *pchInT || abDecode[*pchInT] > 63)
	{
	    // skip all whitespace

	    if (*pchInT == ' ' ||
	        *pchInT == '\t' ||
	        *pchInT == '\r' ||
	        *pchInT == '\n')
	    {
		continue;
	    }

	    if (0 != cchInDecode)
	    {
		if ((cchInDecode % 4) == 0)
		{
		    break;			// ends on quantum boundary
		}

		// The length calculation may stop in the middle of the last
		// translation quantum, because the equal sign padding
		// characters are treated as invalid input.  If the last
		// translation quantum is not 4 bytes long, it must be 2 or 3
		// bytes long.

		if (*pchInT == '=' && (cchInDecode % 4) != 1)
		{
		    break;				// normal termination
		}
	    }
	    err = ERROR_INVALID_DATA;
	    goto error;
	}
	cchInDecode++;
    }
    // GEORGEJ: skip to end of trailer so we can return 
    // number of bytes consumed
    while(*pchInT == '=' && pchInT < pchInEnd)
    	pchInT++;
    if (pchConsumed)
    	*pchConsumed = pchInEnd - pchIn;
    	
    CSASSERT(pchInT <= pchInEnd);
    pchInEnd = pchInT;		// don't process any trailing stuff again

    // We know how many translatable characters are in the input buffer, so now
    // set the output buffer size to three bytes for every four (or fraction of
    // four) input bytes.

    cbOutDecode = ((cchInDecode + 3) / 4) * 3;

    pbOutT = pbOut;

    if (NULL == pbOut)
    {
	pbOutT += cbOutDecode;
    }
    else
    {
	// Decode one quantum at a time: 4 bytes ==> 3 bytes

	CSASSERT(cbOutDecode <= *pcbOut);
	pchInT = pchIn;
	while (cchInDecode > 0)
	{
	    DWORD i;
	    BYTE ab4[4];

	    memset(ab4, 0, sizeof(ab4));
	    for (i = 0; i < min(sizeof(ab4)/sizeof(ab4[0]), cchInDecode); i++)
	    {
		while (
		    sizeof(abDecode) > (unsigned) *pchInT &&
		    63 < abDecode[*pchInT])
		{
		    pchInT++;
		}
		CSASSERT(pchInT < pchInEnd);
		ab4[i] = (BYTE) *pchInT++;
	    }

	    // Translate 4 input characters into 6 bits each, and deposit the
	    // resulting 24 bits into 3 output bytes by shifting as appropriate.

	    // out[0] = in[0]:in[1] 6:2
	    // out[1] = in[1]:in[2] 4:4
	    // out[2] = in[2]:in[3] 2:6

	    *pbOutT++ =
		(BYTE) ((abDecode[ab4[0]] << 2) | (abDecode[ab4[1]] >> 4));

	    if (i > 2)
	    {
		*pbOutT++ =
		  (BYTE) ((abDecode[ab4[1]] << 4) | (abDecode[ab4[2]] >> 2));
	    }
	    if (i > 3)
	    {
		*pbOutT++ = (BYTE) ((abDecode[ab4[2]] << 6) | abDecode[ab4[3]]);
	    }
	    cchInDecode -= i;
	}
	CSASSERT((DWORD) (pbOutT - pbOut) <= cbOutDecode);
    }
    *pcbOut = (DWORD)(pbOutT - pbOut);
error:
    return(err) ;
}


DWORD			// ERROR_*
Base64Encode(
    BYTE const *pbIn,
    DWORD cbIn,
    char *pchOut,
    DWORD *pcchOut)
{
    char *pchOutT;
    DWORD cchOutEncode;

    // Allocate enough memory for full final translation quantum.

    cchOutEncode = ((cbIn + 2) / 3) * 4;

    // and enough for CR-LF pairs for every CB_BASE64LINEMAX character line.

    cchOutEncode +=
	2 * ((cchOutEncode + CB_BASE64LINEMAX - 1) / CB_BASE64LINEMAX);

    pchOutT = pchOut;
    if (NULL == pchOut)
    {
	pchOutT += cchOutEncode;
    }
    else
    {
	DWORD cCol;

	CSASSERT(cchOutEncode <= *pcchOut);
	cCol = 0;
	while ((long) cbIn > 0)	// signed comparison -- cbIn can wrap
	{
	    BYTE ab3[3];

	    if (cCol == CB_BASE64LINEMAX/4)
	    {
		cCol = 0;
		*pchOutT++ = '\r';
		*pchOutT++ = '\n';
	    }
	    cCol++;
	    memset(ab3, 0, sizeof(ab3));

	    ab3[0] = *pbIn++;
	    if (cbIn > 1)
	    {
		ab3[1] = *pbIn++;
		if (cbIn > 2)
		{
		    ab3[2] = *pbIn++;
		}
	    }

	    *pchOutT++ = abEncode[ab3[0] >> 2];
	    *pchOutT++ = abEncode[((ab3[0] << 4) | (ab3[1] >> 4)) & 0x3f];
	    *pchOutT++ = (cbIn > 1)?
			abEncode[((ab3[1] << 2) | (ab3[2] >> 6)) & 0x3f] : '=';
	    *pchOutT++ = (cbIn > 2)? abEncode[ab3[2] & 0x3f] : '=';

	    cbIn -= 3;
	}
	*pchOutT++ = '\r';
	*pchOutT++ = '\n';
	*pchOutT++ = '\0';
	CSASSERT((DWORD) (pchOutT - pchOut) <= cchOutEncode);
    }
    *pcchOut = (DWORD)(pchOutT - pchOut)+1;
	
    return(NOERROR);
}

#if 0
char* __stdcall UnicodeToGBK(const wchar_t* wszIn)
{
	if(!wszIn)return NULL;
	DWORD len= WideCharToMultiByte(CP_ACP,0,wszIn,-1,NULL,0,NULL,NULL);
	char* szOut= (char*)malloc(len+1);
	WideCharToMultiByte(CP_ACP,0,wszIn,-1,szOut,len,NULL,NULL);
	szOut[len]=0;
	return szOut;
}
wchar_t* __stdcall GBKToUnicode(const char* szIn)
{
	if(!szIn)return NULL;
	DWORD len= MultiByteToWideChar(CP_ACP,0,szIn,-1,NULL,0);
	wchar_t* wszOut= (wchar_t*)malloc(sizeof(wchar_t)*(len+1));
	MultiByteToWideChar(CP_ACP,0,szIn,-1,wszOut,len);
	wszOut[len]=0;
	return wszOut;
}
char* __stdcall UnicodeToUTF8(const wchar_t* wszIn)
{
	if(!wszIn)return NULL;
	DWORD len= WideCharToMultiByte(CP_UTF8,0,wszIn,-1,NULL,0,NULL,NULL);
	char* szOut= (char*)malloc(len+1);
	WideCharToMultiByte(CP_UTF8,0,wszIn,-1,szOut,len,NULL,NULL);
	szOut[len]=0;
	return szOut;
}
wchar_t* __stdcall UTF8ToUnicode(const char* szIn)
{
	if(!szIn)return NULL;
	DWORD len= MultiByteToWideChar(CP_UTF8,0,szIn,-1,NULL,0);
	wchar_t* wszOut= (wchar_t*)malloc(sizeof(wchar_t)*(len+1));
	MultiByteToWideChar(CP_UTF8,0,szIn,-1,wszOut,len);
	wszOut[len]=0;
	return wszOut;
}

char* __stdcall GBKToUTF8(const char* szGBK)
{
	if(!szGBK)return NULL;

	wchar_t* wszTmp= GBKToUnicode(szGBK);
	char* szUtf8= UnicodeToUTF8(wszTmp);
	free(wszTmp);

	return szUtf8;
}

char* __stdcall UTF8ToGBK(const char* szUTF8)
{
	if(!szUTF8)return NULL;

	wchar_t* wszTmp= UTF8ToUnicode(szUTF8);
	char* szGBK= UnicodeToGBK(wszTmp);
	free(wszTmp);

	return szGBK;
}
#endif
